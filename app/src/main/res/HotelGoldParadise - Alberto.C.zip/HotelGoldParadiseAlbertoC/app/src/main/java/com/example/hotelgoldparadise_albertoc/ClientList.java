package com.example.hotelgoldparadise_albertoc;

import androidx.appcompat.app.AppCompatActivity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ListView;
import com.example.hotelgoldparadise_albertoc.Data.ClientDbHelper;
import java.util.ArrayList;


public class ClientList extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_list);
        //Creación de la base de datos
        ClientDbHelper myDbHelper = new ClientDbHelper( this);
        SQLiteDatabase db = myDbHelper.getReadableDatabase();

        ListView list = (ListView)findViewById(R.id.listaClientes);

        //LLamada al método de consulta de datos
        ArrayList<Cliente> myPetArray = new ArrayList<Cliente>();
        myPetArray = myDbHelper.displayDataBaseInfo();


        final ArrayList<Cliente> datos = new ArrayList<Cliente>();
        for (Cliente cliente: myPetArray){
            Cliente perrosBD = new Cliente(cliente.getNombre(), cliente.getDni(), cliente.getNum_residentes(), cliente.getNum_dias(), cliente.getHabitacion(), cliente.getNum_habitacion(), cliente.getPrecio());
            datos.add(perrosBD);
        }

        ClientAdapteer ClientAdapter = new ClientAdapteer(this,0, datos);
        list.setAdapter(ClientAdapter);
    }


}
