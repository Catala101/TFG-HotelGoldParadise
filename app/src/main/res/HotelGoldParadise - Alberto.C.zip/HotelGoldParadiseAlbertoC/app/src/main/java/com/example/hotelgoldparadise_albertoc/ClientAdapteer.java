package com.example.hotelgoldparadise_albertoc;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
public class ClientAdapteer extends ArrayAdapter<Cliente>{

    public ClientAdapteer(@NonNull Context context, int resource, @NonNull ArrayList<Cliente> objects) {
        super(context, resource, objects);
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {


        View list_item = convertView;
        //Cogemos el xml con la estructura personalizada del ListView.
        if(list_item == null){
            list_item = LayoutInflater.from(getContext()).inflate(R.layout.item_list_client, parent, false);
        }


        if (position %2 == 1){
            list_item.setBackgroundColor(getContext().getResources().getColor(
                    android.R.color.holo_orange_light
            ));
        }else{
            list_item.setBackgroundColor(getContext().getResources().getColor(
                    android.R.color.white
            ));
        }
        //Traemos los clientes de nuestro Array
        Cliente currentClient = getItem(position);

        TextView primerTexto = (TextView) list_item.findViewById(R.id.nombreCliente);
        primerTexto.setText(currentClient.getNombre());

        TextView segundoTexto = (TextView) list_item.findViewById(R.id.dniCliente);
        segundoTexto.setText(currentClient.getDni());

        TextView tercerTexto = (TextView) list_item.findViewById(R.id.numResidentes);
        tercerTexto.setText(currentClient.getNum_residentes());

        TextView cuartoTexto = (TextView) list_item.findViewById(R.id.numDias);
        cuartoTexto.setText(currentClient.getNum_dias());

        TextView quintoTexto = (TextView) list_item.findViewById(R.id.habitacion);
        quintoTexto.setText(currentClient.getHabitacion());

        TextView sextoTexto = (TextView) list_item.findViewById(R.id.numHabitacion);
        sextoTexto.setText(currentClient.getNum_habitacion());

        TextView septimoTexto = (TextView) list_item.findViewById(R.id.precio);
        septimoTexto.setText(currentClient.getPrecio());

        ImageView imageView = (ImageView) list_item.findViewById(R.id.imagenCliente);
        imageView.setImageResource(currentClient.getImageId());


        //Indices de los datos:
        TextView primerIndice = (TextView) list_item.findViewById(R.id.indiceNombre);
        primerIndice.setText("Nombre:");

        TextView segundoIndice = (TextView) list_item.findViewById(R.id.indiceDni);
        segundoIndice.setText("DNI:");

        TextView tercerIndice = (TextView) list_item.findViewById(R.id.indiceHabitacion);
        tercerIndice.setText("Habitación:");

        TextView cuartoIndice = (TextView) list_item.findViewById(R.id.indiceNumHabitacion);
        cuartoIndice.setText("Nº Habitación:");

        TextView quintoIndice = (TextView) list_item.findViewById(R.id.indiceResidentes);
        quintoIndice.setText("Nº Residentes:");

        TextView sextoIndice = (TextView) list_item.findViewById(R.id.indiceDias);
        sextoIndice.setText("Nº Días:");

        TextView septimoIndice = (TextView) list_item.findViewById(R.id.indicePrecio);
        septimoIndice.setText("Total:");
        return list_item;

    }
}
